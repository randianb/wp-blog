'use strict';

if (mejs.i18n.ca !== undefined) {
	// mejs.i18n.ca["mejs.loop"] = "Toggle Loop";
}
if (mejs.i18n.cs !== undefined) {
	// mejs.i18n.cs["mejs.loop"] = "Toggle Loop";
}
if (mejs.i18n.de !== undefined) {
	mejs.i18n.de["mejs.loop"] = "Wiederholung (de-)aktivieren";
}
if (mejs.i18n.es !== undefined) {
	mejs.i18n.es["mejs.loop"] = "Alternar Repetición";
}
if (mejs.i18n.fr !== undefined) {
	// mejs.i18n.fr["mejs.loop"] = "Toggle Loop";
}
if (mejs.i18n.hr !== undefined) {
	mejs.i18n.hr["mejs.loop"] = "Uključi/isključi ponavljanje";
}
if (mejs.i18n.hu !== undefined) {
	//mejs.i18n.hu["mejs.loop"] = "Toggle Loop";
}
if (mejs.i18n.it !== undefined) {
	//mejs.i18n.it["mejs.loop"] = "Toggle Loop";
}
if (mejs.i18n.ja !== undefined) {
	//mejs.i18n.ja["mejs.loop"] = "Toggle Loop";
}
if (mejs.i18n.ko !== undefined) {
	//mejs.i18n.ko["mejs.loop"] = "Toggle Loop";
}
if (mejs.i18n.nl !== undefined) {
	// mejs.i18n.nl["mejs.loop"] = "Toggle Loop";
}
if (mejs.i18n.pl !== undefined) {
	mejs.i18n.pl["mejs.loop"] = "Zapętl";
}
if (mejs.i18n.pt !== undefined) {
	//mejs.i18n.pt["mejs.loop"] = "";
}
if (mejs.i18n['pt-BR'] !== undefined) {
	//mejs.i18n['pt-BR']["mejs.loop"] = "Toggle Loop";
}
if (mejs.i18n.ro !== undefined) {
	//mejs.i18n.ro["mejs.loop"] = "Toggle Loop";
}
if (mejs.i18n.ru !== undefined) {
	mejs.i18n.ru["mejs.loop"] = "Зациклить воспроизведение";
}
if (mejs.i18n.sk !== undefined) {
	//mejs.i18n.sk["mejs.loop"] = "Toggle Loop";
}
if (mejs.i18n.sv !== undefined) {
	mejs.i18n.sv["mejs.loop"] = "Repetera";
}
if (mejs.i18n.uk !== undefined) {
	mejs.i18n.uk["mejs.loop"] = "Повторювати";
}
if (mejs.i18n.zh !== undefined) {
	//mejs.i18n.zh["mejs.loop"] = "Toggle Loop";
}
if (mejs.i18n['zh-CN'] !== undefined) {
	//mejs.i18n['zh-CN']["mejs.loop"] = "Toggle Loop";
}