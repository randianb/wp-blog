'use strict';

if (mejs.i18n.ca !== undefined) {
	// mejs.i18n.ca["mejs.speed-rate"] = "Speed Rate";
}
if (mejs.i18n.cs !== undefined) {
	// mejs.i18n.cs["mejs.speed-rate"] = "Speed Rate";
}
if (mejs.i18n.de !== undefined) {
	mejs.i18n.de["mejs.speed-rate"] = "Geschwindigkeitsrate";
}
if (mejs.i18n.es !== undefined) {
	mejs.i18n.es["mejs.speed-rate"] = "Tasa de velocidad";
}
if (mejs.i18n.fr !== undefined) {
	// mejs.i18n.fr["mejs.speed-rate"] = "Speed Rate";
}
if (mejs.i18n.hr !== undefined) {
	mejs.i18n.hr["mejs.speed-rate"] = "Brzina reprodukcije";
}
if (mejs.i18n.hu !== undefined) {
	//mejs.i18n.hu["mejs.speed-rate"] = "Speed Rate";
}
if (mejs.i18n.it !== undefined) {
	//mejs.i18n.it["mejs.speed-rate"] = "Speed Rate";
}
if (mejs.i18n.ja !== undefined) {
	//mejs.i18n.ja["mejs.speed-rate"] = "Speed Rate";
}
if (mejs.i18n.ko !== undefined) {
	//mejs.i18n.ko["mejs.speed-rate"] = "Speed Rate";
}
if (mejs.i18n.nl !== undefined) {
	// mejs.i18n.nl["mejs.speed-rate"] = "Speed Rate";
}
if (mejs.i18n.pl !== undefined) {
	mejs.i18n.pl["mejs.speed-rate"] = "Prędkość";
}
if (mejs.i18n.pt !== undefined) {
	//mejs.i18n.pt["mejs.speed-rate"] = "Speed Rate";
}
if (mejs.i18n['pt-BR'] !== undefined) {
	//mejs.i18n['pt-BR']["mejs.speed-rate"] = "Speed Rate";
}
if (mejs.i18n.ro !== undefined) {
	//mejs.i18n.ro["mejs.speed-rate"] = "Speed Rate";
}
if (mejs.i18n.ru !== undefined) {
	mejs.i18n.ru["mejs.speed-rate"] = "Скорость воспроизведения";
}
if (mejs.i18n.sk !== undefined) {
	//mejs.i18n.sk["mejs.speed-rate"] = "Speed Rate";
}
if (mejs.i18n.sv !== undefined) {
	mejs.i18n.sv["mejs.speed-rate"] = "Hastighet";
}
if (mejs.i18n.uk !== undefined) {
	mejs.i18n.uk["mejs.speed-rate"] = "Швидкість відтворення";
}
if (mejs.i18n.zh !== undefined) {
	//mejs.i18n.zh["mejs.speed-rate"] = "Speed Rate";
}
if (mejs.i18n['zh-CN'] !== undefined) {
	//mejs.i18n['zh-CN']["mejs.speed-rate"] = "Speed Rate";
}